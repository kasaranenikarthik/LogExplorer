from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse
from django.template import loader

import os

def index(request):
    path = r"C:\Users\Karthik\Desktop\_Sample_2"
    lst_dir = os.scandir(path)
    template = loader.get_template('LogsDisplay/home.html')
    context = {'lst_dir': lst_dir}
    return HttpResponse(template.render(context, request))

def getFile(request):
    path = r"C:\Users\Karthik\Desktop\_Sample_2\b.py"
    f=open(path,'r')
    fil_data = f.readlines()
    f.close()
    template = loader.get_template('LogsDisplay/file.html')
    context = {'fil_data': fil_data}
    return HttpResponse(template.render(context, request))