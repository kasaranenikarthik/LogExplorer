from django.apps import AppConfig


class LogdRConfig(AppConfig):
    name = 'LogD_R'
